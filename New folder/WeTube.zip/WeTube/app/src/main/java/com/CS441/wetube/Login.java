package com.CS441.wetube;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;



public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

    }
    public void gotoVid(View view) { //OnClick listener for the Login button
        EditText userField = (EditText) findViewById(R.id.usernameField); //gets the editText
        String user = userField.getText().toString(); //grabs the text from the editText
        if(user.equals("")){ //checks to make sure user entered a name
            Toast.makeText(getApplicationContext(),"You must input a username",Toast.LENGTH_SHORT).show();
        }else {
            Intent intent = new Intent(this, RoomSelect.class);
            intent.putExtra("username", user);
            startActivity(intent);
        }
    }
}
