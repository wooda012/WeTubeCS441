package com.CS441.wetube;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class RoomSelect extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference mRef = database.getReference();

    ArrayList<String> rooms =new ArrayList<String>(); //list of rooms to add to listView
    ArrayAdapter<String> adapter; //adapter to put rooms list into listView
    String Username;
    String roomname;
    String password;
    ListView list;
    String tpass; //tempPass, retrieved from database for comparison

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_select);
        list = (ListView)findViewById(R.id.list); //finds the listView to add rooms to
        adapter=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, rooms);
        list.setAdapter(adapter);
        mRef.addListenerForSingleValueEvent(new ValueEventListener() { //listener to grab all current child nodes of the database root (this gets all rooms created)
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot childDataSnapshot : dataSnapshot.getChildren()) { //loop to go through all child nodes
                    String room = childDataSnapshot.getKey(); //gets the roomname of the child
                    rooms.add(room); //adds room to the list
                }
                adapter.notifyDataSetChanged(); //repopulated the listView with all rooms in the roomlist
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        Intent fromMain = getIntent();
        Username = fromMain.getStringExtra("username"); //grab username from the main menu activity in order to pass it on to video room.
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) { //onClick listener for selecting a room from the list
                roomname = (list.getItemAtPosition(position)).toString();
                mRef.child(roomname).child("password").addListenerForSingleValueEvent(new ValueEventListener() { //grabs password of the selected room from Firebase
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        tpass = dataSnapshot.getValue(String.class);
                        if(tpass == null){ //makes sure that the room still exists. If a room is deleted and the user does not refresh their room list, then data received is null
                            Toast.makeText(getApplicationContext(),"Room no longer exists",Toast.LENGTH_SHORT).show();
                        }
                        else {
                            AlertDialog.Builder passAlert = new AlertDialog.Builder(RoomSelect.this); //creating an alert dialog popup to ask for password
                            final EditText editText = new EditText(RoomSelect.this);
                            passAlert.setTitle("Enter Password:");
                            passAlert.setView(editText);
                            passAlert.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    if (editText.getText().toString().equals(tpass)) { //grabs entered password and checks if it matches
                                        Intent intent = new Intent(getApplicationContext(), VideoRoom.class); //creates intent to move to videoroom, and adds data to send as well.
                                        intent.putExtra("username", Username);
                                        intent.putExtra("roomname", roomname);
                                        intent.putExtra("password", tpass);
                                        intent.putExtra("isowner", false);
                                        startActivity(intent);
                                    } else {
                                        Toast.makeText(getApplicationContext(), "Incorrect Password", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                            passAlert.setCancelable(true);
                            AlertDialog alert = passAlert.create();
                            alert.show(); //display alert
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });
    }


    public void createRoom(View view) { //onClick listener for create room button
        AlertDialog.Builder dialog = new AlertDialog.Builder(RoomSelect.this); //creating an alert popup to ask for roomname and password

        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.custom,null); //custom layout for the alertDialog, has a name and password editText
        final EditText nameText = (EditText) dialogView.findViewById(R.id.nameEdit);
        final EditText passText = (EditText) dialogView.findViewById(R.id.passEdit);
        dialog.setView(dialogView);
        dialog.setCancelable(true);
        dialog.setPositiveButton("Create", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                roomname = nameText.getText().toString(); //grabs room name from editText
                password = passText.getText().toString(); //grabs password from editText

                DatabaseReference newRoom = mRef.child(roomname); //creates the room node, and then initializes all the child fields.
                newRoom.child("name").setValue(roomname);
                newRoom.child("owner").setValue(Username);
                newRoom.child("password").setValue(password);
                newRoom.child("state").setValue("pause");
                newRoom.child("time").setValue(0);
                newRoom.child("video").setValue("Temp");
                //newRoom.child("chat").setValue("");
                Intent intent = new Intent(getApplicationContext(), VideoRoom.class); //creates intent to move to videoroom, and adds data to send as well.
                intent.putExtra("username", Username);
                intent.putExtra("roomname", roomname);
                intent.putExtra("password", password);
                intent.putExtra("isowner", true);
                startActivity(intent);
                finish();
            }
        });
        AlertDialog alert = dialog.create();
        alert.show();

    }

    public void backToMenu(View view) { //onClick listener for back to menu button
        Intent intent = new Intent(this, Login.class);
        startActivity(intent);
    }

    public void refreshBut(View view) { //onClick listener for refresh button
        rooms.clear(); //clears the room list array
        mRef.addListenerForSingleValueEvent(new ValueEventListener() { //listener to grab all current child nodes of the database root (this gets all rooms created)
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot childDataSnapshot : dataSnapshot.getChildren()) { //loops over all child nodes
                    String room = childDataSnapshot.getKey(); //gets roomname of child
                    rooms.add(room); //adds to room list
                }
                adapter.notifyDataSetChanged(); //updates listview with room list contents
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
