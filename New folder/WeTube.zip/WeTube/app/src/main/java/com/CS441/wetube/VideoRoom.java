package com.CS441.wetube;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class VideoRoom extends YouTubeBaseActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference mRef = database.getReference();
    boolean isOwner;
    private final String API_KEY = "AIzaSyDqelXSHa6eS0C0-pmOuXjoBokfhnDyhc4"; //youtubeplayer api key
    String videoCode;
    YouTubePlayerView player;
    YouTubePlayer youtubePlayer;
    String username;
    String roomName;
    String password;
    String roomOwner;
    DatabaseReference curRoom;
    Handler handler = new Handler();
    Integer videoTime;
    String state;
    String nState;
    ArrayList<String> chatMes =new ArrayList<String>();
    ArrayAdapter<String> adapter;
    ListView chatbox;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_room);
        roomOwner = "temp";
        videoCode = "temp";
        state  = "pause";
        Intent intent = getIntent(); //grab data sent from room selection screen
        username = intent.getStringExtra("username");
        isOwner = intent.getBooleanExtra("isowner",false); //this is important because isOwner determines much of this activity's functionality
        roomName = intent.getStringExtra("roomname");
        password = intent.getStringExtra("password");
        curRoom = mRef.child(roomName); //sets curRoom to be a database reference to the room the user entered
        if(!isOwner) { //if the user is not the owner, we need to be monitoring if the room is ever deleted
            mRef.addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) { //if we detect that the room has been deleted, go back to room selection screen
                    String removedName = dataSnapshot.child("name").getValue(String.class);
                    if (removedName.equals(roomName)) {
                        Toast.makeText(getApplicationContext(), "Lost Connection to " + roomName, Toast.LENGTH_LONG).show();
                        Intent roomIntent = new Intent(getApplicationContext(), RoomSelect.class);
                        roomIntent.putExtra("username", username);
                        startActivity(roomIntent);
                    }
                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        }

        //create the youtubeplayer and set up all functions on it.
        //I would have liked to make the listeners separate functions, however everything needed to be done in the initialization function,
        //and passing the youtubeplayer as a parameter to separate functions was not working. This makes this section a bit of a mess, however
        //i've left comments on each part.
        player = (YouTubePlayerView)findViewById(R.id.player);
        player.initialize(API_KEY, new YouTubePlayer.OnInitializedListener() {
            @Override
            public void onInitializationSuccess(YouTubePlayer.Provider provider, final YouTubePlayer youTubePlayer, boolean b) {
                if(!b){
                    youTubePlayer.setPlayerStyle(YouTubePlayer.PlayerStyle.CHROMELESS); //this option removes player controls from the youtubeplayer, so that we can use buttons instead
                    youTubePlayer.addFullscreenControlFlag(YouTubePlayer.FULLSCREEN_FLAG_CONTROL_ORIENTATION); //fullscreen the player on horizontal change
                    youTubePlayer.addFullscreenControlFlag(YouTubePlayer.FULLSCREEN_FLAG_ALWAYS_FULLSCREEN_IN_LANDSCAPE);
                    if(!isOwner){ //if the user is not the owner, then they need to set up listeners on the data fields for the room (video code, time, state)
                        mRef.child(roomName).child("video").addValueEventListener(new ValueEventListener() { //this listener checks for changes in the video watch code field
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                videoCode = dataSnapshot.getValue(String.class); //grab new watch code
                                if(videoCode == null){ //null check, go back to room selection if true
                                    Toast.makeText(getApplicationContext(), "Lost Connection to " + roomName, Toast.LENGTH_LONG).show();
                                    Intent roomIntent = new Intent(getApplicationContext(), RoomSelect.class);
                                    roomIntent.putExtra("username", username);
                                    startActivity(roomIntent);
                                }
                                youTubePlayer.cueVideo(videoCode); //else if not null, load new video code
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                            }
                        });
                        mRef.child(roomName).child("time").addValueEventListener(new ValueEventListener() { //this listener checks for changes in the video time
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                videoTime = dataSnapshot.getValue(Integer.class); //grabs new video time
                                if(videoTime == null){ //null check, go back to room selection if true
                                    Toast.makeText(getApplicationContext(), "Lost Connection to " + roomName, Toast.LENGTH_LONG).show();
                                    Intent roomIntent = new Intent(getApplicationContext(), RoomSelect.class);
                                    roomIntent.putExtra("username", username);
                                    startActivity(roomIntent);
                                }
                                else if(Math.abs(videoTime - youTubePlayer.getCurrentTimeMillis()) > 1000){ //else if not null, find the offset between retrieved video time and client video time
                                    youTubePlayer.seekToMillis(videoTime + 500); //if the offset is over 1 second, set client video time to retrieved time + 500ms to account for buffering
                                }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                        mRef.child(roomName).child("state").addValueEventListener(new ValueEventListener() { //this listener checks for changes in the video playback state
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                nState = dataSnapshot.getValue(String.class); //grabs new playback state
                                if(nState == null){ //null check, go back to room selection if true
                                    Toast.makeText(getApplicationContext(), "Lost Connection to " + roomName, Toast.LENGTH_LONG).show();
                                    Intent roomIntent = new Intent(getApplicationContext(), RoomSelect.class);
                                    roomIntent.putExtra("username", username);
                                    startActivity(roomIntent);
                                }
                                else if(nState.equals("play")){ //else if not null and new state is play
                                    youTubePlayer.play(); //play clientside video
                                }
                                else{ //else if not null and new state is pause
                                    youTubePlayer.pause(); //pause the clientside player
                                    youTubePlayer.seekToMillis(videoTime+500); //resync clientside player to host's video time + 500ms to account for buffering
                                }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                            }
                        });




                    }
                    handler.postDelayed(new Runnable(){
                        @Override
                        public void run(){ //this handler will run every 125ms
                            if(youTubePlayer.isPlaying() && isOwner) { //if the video is currently playing and client is the owner, send time updates to the database
                                mRef.child(roomName).child("time").setValue(youTubePlayer.getCurrentTimeMillis()+125); //send current player time + 125ms to account for buffering
                            }
                            handler.postDelayed(this,125);
                        }
                    },125);


                    Button newVideo = (Button)findViewById(R.id.newvidBut); //onClick listener for newVideo button
                    newVideo.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if(isOwner) { //checks to make sure user is owner, else cannot change video.
                                AlertDialog.Builder vidAlert = new AlertDialog.Builder(VideoRoom.this); //alertDialog popup asking for new watch code
                                final EditText editText = new EditText(VideoRoom.this);
                                vidAlert.setTitle("Enter Video ID:");
                                vidAlert.setView(editText);
                                vidAlert.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) { //on confirm, set new videocode to the entered one, load video in player, and update database
                                        videoCode = editText.getText().toString();
                                        youTubePlayer.cueVideo(videoCode, 0);
                                        mRef.child(roomName).child("video").setValue(videoCode);
                                    }
                                });
                                vidAlert.setCancelable(true);
                                AlertDialog alert = vidAlert.create();
                                alert.show();
                            }
                            else{
                                Toast.makeText(getApplicationContext(),"Only the room owner can edit state", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    Button playButton = (Button) findViewById(R.id.playBut); //onClick listener for the play Button
                    playButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if(isOwner) { //checks to make sure user is owner, else cannot update playback state
                                youTubePlayer.play(); //plays video
                                mRef.child(roomName).child("state").setValue("play"); //updates database playback state
                            }
                            else{
                                Toast.makeText(getApplicationContext(),"Only the room owner can edit state", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    Button pauseButton = (Button) findViewById(R.id.pauseBut); //onClick listener for the pause button
                    pauseButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if(isOwner) { //checks to make sure user is owner, else cannot update playback state
                                youTubePlayer.pause(); //pause video
                                mRef.child(roomName).child("state").setValue("pause"); //update database playback state
                                mRef.child(roomName).child("time").setValue(youTubePlayer.getCurrentTimeMillis()); //send current video time to database for syncing
                            }
                            else{
                                Toast.makeText(getApplicationContext(),"Only the room owner can edit state", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    Button seekButton = (Button)findViewById(R.id.timeBut); //onClick listener for time select button
                    seekButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if(isOwner) { //checks to make sure user is owner, else cannot update video time
                                AlertDialog.Builder vidAlert = new AlertDialog.Builder(VideoRoom.this); //alertDialog popup to enter time in
                                final EditText editText = new EditText(VideoRoom.this);
                                vidAlert.setTitle("Enter Time (seconds)");
                                vidAlert.setView(editText);
                                vidAlert.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        youTubePlayer.seekToMillis(Integer.valueOf(editText.getText().toString()) * 1000); //seeks client player to new time
                                        mRef.child(roomName).child("time").setValue(Integer.valueOf(editText.getText().toString())*1000); //updates database with new time
                                    }
                                });
                                vidAlert.setCancelable(true);
                                AlertDialog alert = vidAlert.create();
                                alert.show();
                            }
                            else{
                                Toast.makeText(getApplicationContext(),"Only the room owner can edit state", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }

            }

            @Override
            public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {
            }
        });
        //finished youtubeplayer initialization


        chatbox = (ListView)findViewById(R.id.chatbox); //finding the listView that is our chatbox
        adapter=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, chatMes); //creating an array to hold chat messages
        chatbox.setAdapter(adapter); //adapter to add chat array to listView
        mRef.child(roomName).child("chat").addValueEventListener(new ValueEventListener() { // this listener checks for changes in the chat field
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String message = dataSnapshot.getValue(String.class); //grab new chat message
                if(message != null){ //null check
                    chatMes.add(message); //add message to chat array
                    adapter.notifyDataSetChanged(); //update listview with new chat array contents
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
        if(isOwner){ //On disconnecting from the Firebase database, remove the room. IF TIME ADD HOST MIGRATION HERE
            mRef.child(roomName).onDisconnect().removeValue();
        }
    }
    public void sendMSG(View view) { //onClick listener for the send message button

        EditText messageText = (EditText)findViewById(R.id.chatText);
        String newmessage = username + ": " + messageText.getText().toString(); //grab entered message from editText and add username to the string
        mRef.child(roomName).child("chat").setValue(newmessage); //update most recent chat message in database
        messageText.setText(""); //reset the editText so that user doesn't need to delete their previous message
        View focusview = this.getCurrentFocus(); //gets the focused keyboard
        if (focusview != null) { //if the keyboard is focused, hide it. This prevents keyboard from lingering upon sending a message.
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }

    }

    public void toMain(View view) { //onClick listener for main menu button
        if(isOwner) { //if owner, remove the room
            mRef.child(roomName).removeValue();
        }
        Intent mainIntent = new Intent(this, Login.class); //go to main menu
        startActivity(mainIntent);
    }

    public void toRoomSelect(View view) {
        if(isOwner) { //if owner, remove the room
            mRef.child(roomName).removeValue();
        }
        Intent roomIntent = new Intent(this, RoomSelect.class); //go to room select and send back client username as well
        roomIntent.putExtra("username", username);
        startActivity(roomIntent);
    }

    public void OnPause(){ //when the activity is paused, remove the room
        mRef.child(roomName).removeValue();
        super.onPause();
    }

}
