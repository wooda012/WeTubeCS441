Where to find source files:

JAVA CODE:
WeTube/app/src/main/java/com/cs441/wetube

XML FILES:
WeTube/app/src/main/res/layout

Release APK:
the WeTube.apk file in the main folder should be fine, if there is an issue please see
WeTube/app/release/app-release.apk